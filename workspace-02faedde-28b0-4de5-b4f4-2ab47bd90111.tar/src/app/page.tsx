"use client";

import { useState, useEffect, useCallback } from "react";
import Image from "next/image";
import {
  Trophy,
  Swords,
  Shuffle,
  History,
  Users,
  Menu,
  X,
} from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import Leaderboard from "@/components/spikeball/Leaderboard";
import PlayersTab from "@/components/spikeball/PlayersTab";
import RecordGame from "@/components/spikeball/RecordGame";
import GenerateGames from "@/components/spikeball/GenerateGames";
import GameHistory from "@/components/spikeball/GameHistory";

interface Player {
  id: string;
  name: string;
  eloRating: number;
  gamesPlayed: number;
  wins: number;
  losses: number;
  lastPlayedAt: string | null;
}

export default function SpikeballPage() {
  const [players, setPlayers] = useState<Player[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshTrigger, setRefreshTrigger] = useState(0);
  const [activeTab, setActiveTab] = useState("leaderboard");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const fetchPlayers = useCallback(async () => {
    try {
      const res = await fetch("/api/players");
      if (res.ok) {
        const data = await res.json();
        setPlayers(data);
      }
    } catch (err) {
      console.error("Error fetching players:", err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchPlayers();
  }, [fetchPlayers, refreshTrigger]);

  const handlePlayersChange = useCallback(() => {
    fetchPlayers();
    setRefreshTrigger((prev) => prev + 1);
  }, [fetchPlayers]);

  const handleGameRecorded = useCallback(() => {
    fetchPlayers();
    setRefreshTrigger((prev) => prev + 1);
  }, [fetchPlayers]);

  const tabItems = [
    { value: "leaderboard", label: "Rangliste", icon: Trophy },
    { value: "record", label: "Spiel eintragen", icon: Swords },
    { value: "generate", label: "Matchups", icon: Shuffle },
    { value: "history", label: "Verlauf", icon: History },
    { value: "players", label: "Spieler", icon: Users },
  ];

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-orange-50 via-background to-amber-50 dark:from-orange-950/20 dark:via-background dark:to-amber-950/20">
        <div className="text-center text-muted-foreground">
          <div className="h-12 w-12 mx-auto mb-4 rounded-full border-2 border-orange-500 border-t-transparent animate-spin" />
          <p>Lade Spikeball ELO System...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-orange-50 via-background to-amber-50 dark:from-orange-950/20 dark:via-background dark:to-amber-950/20">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b bg-background/80 backdrop-blur-xl">
        <div className="max-w-4xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="relative h-10 w-10 rounded-xl overflow-hidden shadow-sm">
              <Image
                src="/spikeball-logo.png"
                alt="Spikeball"
                fill
                className="object-cover"
              />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight">Spikeball ELO</h1>
              <p className="text-xs text-muted-foreground hidden sm:block">
                Individual Rating System für 2v2 Matches
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="hidden sm:flex items-center gap-1.5 text-sm text-muted-foreground">
              <Users className="h-4 w-4" />
              <span>{players.length} Spieler</span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-4xl mx-auto w-full px-4 py-6">
        {/* Mobile Tab Navigation */}
        <div className="block sm:hidden mb-4">
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="flex items-center justify-between w-full p-3 rounded-lg border bg-card text-sm font-medium"
          >
            <span className="flex items-center gap-2">
              {tabItems.find((t) => t.value === activeTab) && (
                <>
                  {(() => {
                    const TabIcon = tabItems.find((t) => t.value === activeTab)?.icon || Menu;
                    return <TabIcon className="h-4 w-4" />;
                  })()}
                  {tabItems.find((t) => t.value === activeTab)?.label}
                </>
              )}
            </span>
            {mobileMenuOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
          </button>
          {mobileMenuOpen && (
            <div className="mt-2 rounded-lg border bg-card p-2 space-y-1">
              {tabItems.map((tab) => {
                const Icon = tab.icon;
                return (
                  <button
                    key={tab.value}
                    onClick={() => {
                      setActiveTab(tab.value);
                      setMobileMenuOpen(false);
                    }}
                    className={`flex items-center gap-2 w-full p-2.5 rounded-md text-sm transition-colors ${
                      activeTab === tab.value
                        ? "bg-primary text-primary-foreground"
                        : "text-foreground hover:bg-muted"
                    }`}
                  >
                    <Icon className="h-4 w-4" />
                    {tab.label}
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* Desktop Tab Navigation */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="hidden sm:inline-flex w-full justify-start rounded-lg bg-muted p-1 h-auto">
            {tabItems.map((tab) => {
              const Icon = tab.icon;
              return (
                <TabsTrigger
                  key={tab.value}
                  value={tab.value}
                  className="flex items-center gap-2 rounded-md data-[state=active]:bg-background data-[state=active]:shadow-sm text-sm"
                >
                  <Icon className="h-4 w-4" />
                  {tab.label}
                </TabsTrigger>
              );
            })}
          </TabsList>

          <TabsContent value="leaderboard" className="mt-6">
            <Leaderboard onRefreshTrigger={refreshTrigger} />
          </TabsContent>

          <TabsContent value="record" className="mt-6">
            <RecordGame players={players} onGameRecorded={handleGameRecorded} />
          </TabsContent>

          <TabsContent value="generate" className="mt-6">
            <GenerateGames players={players} />
          </TabsContent>

          <TabsContent value="history" className="mt-6">
            <GameHistory
              onRefreshTrigger={refreshTrigger}
              onGameDeleted={handleGameRecorded}
            />
          </TabsContent>

          <TabsContent value="players" className="mt-6">
            <PlayersTab players={players} onPlayersChange={handlePlayersChange} />
          </TabsContent>
        </Tabs>
      </main>

      {/* Footer */}
      <footer className="border-t mt-auto">
        <div className="max-w-4xl mx-auto px-4 py-4 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-muted-foreground">
          <span>Spikeball ELO Rating System</span>
          <span>ELO-Decay: 5% pro inaktivem Monat</span>
        </div>
      </footer>
    </div>
  );
}
