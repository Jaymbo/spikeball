import { db } from "@/lib/db";
import { NextRequest, NextResponse } from "next/server";

// GET /api/players - List all players
export async function GET() {
  try {
    const players = await db.player.findMany({
      orderBy: { eloRating: "desc" },
      include: {
        _count: {
          select: { eloChanges: true },
        },
      },
    });

    return NextResponse.json(players);
  } catch (error) {
    console.error("Error fetching players:", error);
    return NextResponse.json({ error: "Failed to fetch players" }, { status: 500 });
  }
}

// POST /api/players - Create a new player
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { name } = body;

    if (!name || typeof name !== "string" || name.trim().length === 0) {
      return NextResponse.json({ error: "Name is required" }, { status: 400 });
    }

    const trimmedName = name.trim();

    // Check if player already exists
    const existing = await db.player.findUnique({
      where: { name: trimmedName },
    });

    if (existing) {
      return NextResponse.json({ error: "Player already exists" }, { status: 409 });
    }

    const player = await db.player.create({
      data: { name: trimmedName },
    });

    return NextResponse.json(player, { status: 201 });
  } catch (error) {
    console.error("Error creating player:", error);
    return NextResponse.json({ error: "Failed to create player" }, { status: 500 });
  }
}

// DELETE /api/players?id=xxx - Delete a player
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json({ error: "Player ID is required" }, { status: 400 });
    }

    // Check if player has games
    const gamesCount = await db.game.count({
      where: {
        OR: [
          { team1Player1Id: id },
          { team1Player2Id: id },
          { team2Player1Id: id },
          { team2Player2Id: id },
        ],
      },
    });

    if (gamesCount > 0) {
      return NextResponse.json(
        { error: `Cannot delete player with ${gamesCount} game(s). Delete games first.` },
        { status: 409 },
      );
    }

    await db.eloChange.deleteMany({ where: { playerId: id } });
    await db.player.delete({ where: { id } });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Error deleting player:", error);
    return NextResponse.json({ error: "Failed to delete player" }, { status: 500 });
  }
}
